import React from 'react';

// type Props = {}

const InviteOnlyTip = () => {
    return (
        <div className='flex-1 dark:text-white flex items-center justify-center'>
            Only Invite to SignUp
        </div>
    );
};

export default InviteOnlyTip;