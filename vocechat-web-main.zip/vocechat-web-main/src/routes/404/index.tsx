
export default function NotFoundPage() {
  return <div>404 page</div>;
}
