# shared hooks used across the entire application
